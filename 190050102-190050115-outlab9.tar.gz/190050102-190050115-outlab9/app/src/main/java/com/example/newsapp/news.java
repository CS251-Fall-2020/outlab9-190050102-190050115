package com.example.newsapp;

public class news {
    private final String title;

    public news(String _title){
        this.title = _title;
    }

    public String getTitle(){
        return this.title;
    }
}
