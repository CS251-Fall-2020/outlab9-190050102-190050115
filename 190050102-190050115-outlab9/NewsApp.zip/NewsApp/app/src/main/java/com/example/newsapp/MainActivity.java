package com.example.newsapp;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.AuthFailureError;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.Volley;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.TextView;


import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {
    String url = "http://newsapi.org/v2/everything?q=bitcoin&from=2020-11-11&sortBy=publishedAt&apiKey=092aed190dfd4301b0205292d22b00cd";
    private TextView textView;
    private RequestQueue requestQueue;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        textView = findViewById(R.id.textView1);
        requestQueue = Volley.newRequestQueue(this);
        volleyGet();
    }

    public void volleyGet(){
        String url = "https://bing-news-search1.p.rapidapi.com/news?safeSearch=Off&textFormat=Raw";

        RequestQueue requestQueue = Volley.newRequestQueue(this);
        JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(Request.Method.GET, url, null, new Response.Listener<JSONObject>() {
            @Override
            public void onResponse(JSONObject response) {
                try {
                    JSONArray jsonArray = response.getJSONArray("value");

                    for(int i=0; i< jsonArray.length(); i++){
                        JSONObject article = jsonArray.getJSONObject(i);
                        String name = article.getString("name");
                        textView.setText('\"' + name + '\"');
                    }
                } catch (JSONException e) {
                    e.printStackTrace();
                }
            }
        }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                error.printStackTrace();
            }
        }) {
            @org.jetbrains.annotations.NotNull
            @Override
            public Map<String, String> getHeaders() throws AuthFailureError {
                Map<String, String> params = new HashMap<String, String>();
                params.put("Content-Type", "application/json");
                params.put("x-bingapis-sdk", "true");
                params.put("x-rapidapi-key", "623994d80emsh75e99be54b62f74p1cd3b7jsndcfb41111e2c");
                params.put("x-rapidapi-host", "bing-news-search1.p.rapidapi.com");
                return params;
            }
        };

        requestQueue.add(jsonObjectRequest);

    }
}